package com.srn.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SrnApplication {

	public static void main(String[] args) {
		SpringApplication.run(SrnApplication.class, args);
	}

}
